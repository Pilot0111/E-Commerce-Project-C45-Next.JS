import { ICategory } from "@/interfaces/categories.interfaces";

export default async function getCategories() {
    try {
      const response = await fetch(
        "https://ecommerce.routemisr.com/api/v1/categories",
        {
          cache: "no-store",
        }
      );

      if (!response.ok) {
        throw new Error(response.statusText || "Failed to fetch categories");
      }

      const { data }:{data:ICategory[]} = await response.json();
      console.log(data);
      return data;
      
    } catch (error) {
      console.error("Error fetching categories:", error);
      return null; // return null instead of undefined
    }
  }

  