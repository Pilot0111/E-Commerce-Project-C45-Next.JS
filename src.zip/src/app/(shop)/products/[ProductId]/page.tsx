import AddToCartBtn from "@/components/products/AddToCartBtn";
import AddToWishListBtn from "@/components/products/AddToWishListBtn";
import ProductSwiper from "@/components/products/ProductSwiper";
import { IProducts } from "@/interfaces/products.interfaces";
import { getProductDetails } from "@/services/products.service";
import { Star } from "lucide-react";
import React from "react";

export default async function ProductDetails({
  params: { ProductId },
}: {
  params: { ProductId: string };
}) {
  const { data }: { data: IProducts } = await getProductDetails(ProductId);

  return (
    <section className="h-[80vh] flex items-center justify-center">
      <div className="container mx-auto flex items-center justify-center mt-8 h-full">
        <div className="overflow-hidden grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 Qxl:grid-cols-4 gap-10 h-full">
          <div className="lg:col-span-2 max-h-full">
            <ProductSwiper images={data.images} />
          </div>

          <div className="lg:col-span-1 h-full">
            <h1 className="text-2xl font-semibold mb-4">{data.title}</h1>

            <div className="flex items-center gap-x-1 mb-4">
              <Star className="text-yellow-500 fill-yellow-500" />
              <span className="text-sm font-semibold text-gray-500">
                {data.ratingsAverage}
              </span>
            </div>

            <span className="mb-6 text-2xl block">{data.price} EGP</span>

            <p className="pb-6 border-b border-b-gray-400 text-sm">
              {data.description}
            </p>

            {/* Full-width Add to Cart */}
            <AddToCartBtn
              productId={data._id}
              className="w-full mt-6 cursor-pointer"
              variant={"destructive"}
            />

            {/* Full-width Add to Wishlist */}
            <AddToWishListBtn
              productId={data._id}
              variant="full"
              className="w-full mt-4 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
