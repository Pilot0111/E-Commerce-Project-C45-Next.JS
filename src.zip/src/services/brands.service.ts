import { IBrand } from "@/interfaces/brand.interface";

export default async function getBrands() {
    try {
      const response = await fetch(
        "https://ecommerce.routemisr.com/api/v1/brands",
        {
          cache: "no-store",
        }
      );

      if (!response.ok) {
        throw new Error(response.statusText || "Failed to fetch categories");
      }

      const { data }:{data:IBrand[]} = await response.json();
      console.log(data);
      return data;
      
    } catch (error) {
      console.error("Error fetching brands:", error);
      return null; // return null instead of undefined
    }
  }

  