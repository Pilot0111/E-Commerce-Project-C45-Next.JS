"use server";

import { formStateType, RegisterFormSchema } from "@/schema/Register.schema";

export async function HandelRegister(
  formState: formStateType,
  formData: FormData
): Promise<formStateType> {
  console.log("this is the HandelRegister", formData);
  const formValues = {
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    rePassword: formData.get("rePassword"),
    phone: formData.get("phone"),
  };
  console.log("this is the formValues", formValues);

  const parsedData = RegisterFormSchema.safeParse(formValues);
  console.log("this is the parsedData", parsedData);
  console.log(parsedData.error?.flatten().fieldErrors);

  if (!parsedData.success) {
    return {
      error: parsedData.error?.flatten().fieldErrors,
      success: false,
      message: null,
    };
  }

  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL_API}auth/signup`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formValues),
      }
    );
    const data = await response.json();
    console.log(data);
    if (!response.ok) {
      return { error: {}, success: false, message: data.message };
    }
    return { error: {}, success: true, message: data.message };
  } catch (error) {
    return { error: {}, success: false, message: error as string };
  }
}
