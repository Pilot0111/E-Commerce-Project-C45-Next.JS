
export interface ISubcategory {
  _id: string
  name: string
  slug: string
  category: string
}
