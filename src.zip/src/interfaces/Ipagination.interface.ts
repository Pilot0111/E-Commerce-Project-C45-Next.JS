
export interface IPagination {
  currentPage: number
  numberOfPages: number
  limit: number
}