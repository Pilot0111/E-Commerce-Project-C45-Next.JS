
export interface IBrand {
  _id: string
  name: string
  slug: string
  image: string
}
