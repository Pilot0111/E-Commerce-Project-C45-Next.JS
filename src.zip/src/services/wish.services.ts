"use server";

import { getUserToken } from "@/lib/serverUtility";

export async function getWishCart() {
  try {
    const token = await getUserToken();
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL_API}wishlist`, {
      method: "GET",
      headers: {
        token: token as string,
      },
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message);
    }
    console.log("this is from getUserToken in wish services page", data);
    return data;
  } catch (error) {
    console.log(error);
  }
}

export async function removeUserWish(productID: string) {
  try {
    const token = await getUserToken();
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL_API}wishlist/${productID}`,
      {
        method: "DELETE",
        headers: {
          token: token as string,
        },
      }
    );
    const data = await res.json();
    if (!res.ok) {
      return {
        data: null,
        success: false,
        message: data.message || "Add to wishlist failed",
      };
    }
    console.log("this is from removeUserWish", data);
    return {
      data: data,
      success: true,
      message: data.message || "Item removed from wishlist successfully",
    };
  } catch (error) {
    return {
        data: null,
        success: false,
        message: (error as string) || "Add to wishlist failed",
      };
  }
}

export async function addToWish(productId: string) {
  try {
    const token = await getUserToken();
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL_API}wishlist`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        token: token as string,
      },
      body: JSON.stringify({ productId }),
    });
    const data = await res.json();
    if (!res.ok) {
      return {
        data: null,
        success: false,
        message: data.message || "Add to wishlist failed",
      };
    }
    console.log("this is the data from add to wishlist", data);
    return {
      data: data,
      success: true,
      message: data.message || "Item added to wishlist successfully",
    };
  } catch (error) {
    console.log(error);
    return {
      data: null,
      success: false,
      message: (error as string) || "Add to wishlist failed",
    };
  }
}
