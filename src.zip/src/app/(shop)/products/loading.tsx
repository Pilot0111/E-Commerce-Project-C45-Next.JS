import React from 'react'

export default function Loading() {
  return (
    <>
    <div className="container mx-auto flex items-center justify-center mt-50">
      <div className="loader"></div>

    </div>
   
   </>
  )
}
