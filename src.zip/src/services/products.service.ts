import { IProducts } from "@/interfaces/products.interfaces";

export default async function getProducts(limit: 40 | 8) {
  try {
    const response = await fetch(
      "https://ecommerce.routemisr.com/api/v1/products?limit=" + limit,
      // `https://ecommerce.routemisr.com/api/v1/products?limit=${limit}`,
      {
        // cache: "no-store", //to always fetch the latest data
        cache: "no-cache",
        // next: { revalidate: 120, tags: ["products"] },
      }
    );

    if (!response.ok) {
      throw new Error(response.statusText || "Failed to fetch products");
    }

    const { data }: { data: IProducts[] } = await response.json();
    console.log(data);
    return data;
  } catch (error) {
    console.error("Error fetching categories:", error);
    return null; // return null instead of undefined
  }
}

export async function getProductDetails(id: string) {
  try {
    const response = await fetch(
      `https://ecommerce.routemisr.com/api/v1/products/${id}`,
      {
        cache: "no-cache",
      }
    );

    if (!response.ok) {
      throw new Error(response.statusText || "Failed to fetch product details");
    }

    const data = await response.json(); //retun data whihout sepecifiing the type which will be done in the other page
    console.log(data);
    return data;
  } catch (error) {
    console.error("Error fetching categories:", error);
    return null; // return null instead of undefined
  }
}
